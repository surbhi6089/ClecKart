// for product filter
$(document).ready(function(){
    filterSearch();
    console.log("Unable");
    $('.productDetail').click(function(){
      filterSearch();
      console.log("HEY");
    });
  });
  function filterSearch(){
    $('.filt2').html('<div id= "loading">Loading....</div>');
    // $('.filt2').html('.product-card');
    var action = 'fetch_data';
    var protype = getFilterData('PROTYPE');
  
    $.ajax(
    {
      url: "action.php",
      method: "POST",
      dataType: "json",
      data: {action:action, PROTYPE:protype},
      success:function(data){
        $('.filt2').html(data.html);

        console.log('hah');
      }
    }
    );
  }
  function getFilterData(className){
    var filter = [];
    $('.'+className+':checked').each(function(){
      filter.push($(this).val());
    });
    return filter;
    
  }
  