<?php 
  include_once('connect.php');
  if(isset($_POST['SearchButton'])){
    if(!empty($_POST['Search'])){
      $searchTerm = $_POST['Search'];
    }
    // $query = oci_parse($conn, "SELECT ")
    
  }
  
  include_once('class.php');
  $product = new Product();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/9.8.0/css/bootstrap-slider.min.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-slider/9.8.0/bootstrap-slider.min.js"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/
jquery.min.js"></script>
    <link rel="stylesheet" href="head.css" />
    <link rel="stylesheet" href="product.css" />
    <!-- <script src="home.js" defer></script> -->
  
   
    <script src="https://kit.fontawesome.com/4d1c2a430c.js" crossorigin="anonymous"></script>
  </head>
  <body>
    <!-- header start -->
    <header class="header">
      <div class="menu-btn">
        <div class="menu-btn_burger"></div>
      </div>
      <div id="logo">
        <img src="ClecKart-Logo.png" height="95px" width="170px" />
      </div>
      <div class="search">
        <form id="tfnewsearch" method="POST" action="">
          <input
            type="text"
            class="tftextinput"
            placeholder="Search in ClecKart..."
            name="Search"
            size="21"
            maxlength="120"
          /><input type="submit" value="search" class="tfbutton" name="SearchButton"/>
        </form>
      </div>
      <div class="links">
        <button type="submit"  onclick="window.location.href='RegisterPage.php';" disabled>Sign Up</button>
        <a href="login.html"><i class="fa-solid fa-circle-user far"></i></a>
        <a><i class="fas fa-shopping-cart" onclick="on()"></i></a>
        <a href="#"><i class="far fa-heart"></i></a>
      </div>
    </header>
    <div id="overlay" onclick="off()"><div class="cart">
 sdsfgdfsdf
    </div></div>
    <div class="dummy"></div>
    <!-- nav2 -->
    <nav>
      <ul>
        <li>
          <a href="aboutus.html">Category<i class="fas fa-info-circle"></i></a>
        </li>
        <li>
          <a href="product.html"
            >Category<i class="fas fa-air-freshener"></i
          ></a>
        </li>
        <li>
          <a href="cart.html">Category<i class="fas fa-shopping-cart"></i></a>
        </li>
        <li>
          <a href="contact.html">Category<i class="far fa-envelope"></i></a>
        </li>
      </ul>
    </nav>
    <!-- <div class="sidepanel" id="sidepanel">
      <a href="aboutus.html">Category<i class="fas fa-info-circle"></i></a>
      <a href="product.html">Category<i class="fas fa-air-freshener"></i></a>
      <a href="contact.html">Category<i class="far fa-envelope"></i></a>
      <a href="cart.html">Category<i class="fas fa-shopping-cart"></i></a>
    </div> -->

    <!-- nav2 end -->
    <!-- ---------------------------header end---------------------------------------- -->


  <!-------------------------------PRODUCT PAGE  ------------------------------------------->

  <div class="product-container">
      <div class="filt1">
          <div class="filter">
                <h1>Filters</h1>
                <div class="sort1">
                  <h3>Filter by Product Type</h3>
                  <div class="filthy">
                    <?php
                   
                    $pro = $product->getProType();
                    
                    foreach($pro  as $proDetails){

                    ?>
                    <div class="checkbox">
                      <label ><input type="checkbox"  class= "productDetail PROTYPE" value = "<?php echo $proDetails['PROTYPE']; ?>"><?php echo " ". $proDetails['PROTYPE']; ?></label>
                    </div>
                    <?php } ?>
                  </div>
                </div>
                <div class="sort2">
                    <h3>Product Type</h3>
                   
                    <br>
                    
                </div>
          </div>
      </div>
      <div class="filt2">  
    </div>
  </div>
    <!----------------------------------- footer start -------------------------------------->

    <!-- *********************************************************** -->
    <footer>
      <div class="container">
        <div class="first box">
          <h2>Quick Links</h2>
          <p class="link">
            <a href="aboutus.html">Home</a>
            <a href="product.html">Login</a>
            <a href="aboutus.html">Cart</a>
            <a href="aboutus.html">WishList</a>
          </p>
        </div>
        <div class="second box">
          <h2>Contact Us</h2>
          <p class="link">
            <a
              href="https://www.google.com/maps/place/Sherpa+Mall/@27.7105497,85.3156752,17z/data=!3m1!4b1!4m5!3m4!1s0x39eb19015ce34aa3:0x833d1f9f02d0db2d!8m2!3d27.710545!4d85.3178639"
              ><i class="fas fa-map-marker-alt"></i>Cleckhuddersfax</a
            >
            <a href="tel:+9770913582040"
              ><i class="fas fa-phone"></i>+9770913582040</a
            >
            <a href="tel:+9770913582040"
              ><i class="fas fa-phone"></i>+9770913582040</a
            >

            <a href="mailto:fragrance@gmail.com"
              ><i class="far fa-envelope"></i>info.clekart@gmail.com</a
            >
          </p>
        </div>
        <div class="third box">
          <h2>Information</h2>
          <p class="link">
            <a href="https://www.facebook.com/">About Us </a>
            <a href="https://www.instagram.com/">Delivery Information</a>
            <a href="https://www.youtube.com/">Privacy Policy </a>
            <a href="https://twitter.com/?lang=en">Offic location </a>
          </p>
        </div>

        <div class="fourth box">
          <h2>Social Medias</h2>
          <p class="link">
            <a href="https://www.facebook.com/"
              ><i class="fab fa-facebook-f"></i> Facebook
            </a>
            <a href="https://www.instagram.com/"
              ><i class="fab fa-instagram"></i>Instagram</a
            >
            <a href="https://www.youtube.com/"
              ><i class="fab fa-youtube"></i>Youtube
            </a>
            <a href="https://twitter.com/?lang=en"
              ><i class="fab fa-twitter"></i>Twitter
            </a>
          </p>
        </div>
      </div>
    </footer>
    <div class="bottom-box">&copy; 2020 ClecKart. All Rights Reserved.</div>
    <!-- ******************************************************************** -->

    <!-- footer end -->
    <script src="search.js"></script>


  </body>
</html>