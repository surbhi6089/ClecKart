<?php
class Product{
    private $host = '//localhost/xe';
    private $user = 'tamrakar';
    private $password = 'A!12x34';
    private $productTable = 'PRODUCT';
    private $dbConnect = false;

    public function __construct(){
        if(!$this->dbConnect){
            $conn =  oci_connect($this->user, $this->password , $this->host); 
            if(!$conn){
                die("Error failed to connect to Oracle ".$conn->oci_error);
            }
            else{
                $this->dbConnect = $conn;
                // print "connected to oracle";
            }
           
        }
    }
    // get data
    private function getData($sqlQuery){
        $result = oci_parse($this->dbConnect, $sqlQuery);
        oci_execute($result);
        if(!$result){
            die('Error in query: '. oci_error());
        }
        $data = array();
        
        while($row = oci_fetch_array($result, OCI_ASSOC)){
            $data[] = $row;
           
        }
        return $data;
      
        
    }
    
    public function getProType(){
        $sqlQuery = "SELECT DISTINCT(PROTYPE), PROID FROM ".$this->productTable." WHERE STATUS = 'Available' ORDER BY PROID , PROTYPE ASC ";
        return $this->getData($sqlQuery);
    }
    public function searchProducts(){
        $sqlQuery = "SELECT NAME, IMAGE, PRICE FROM ".$this->productTable." WHERE STATUS = 'Available' ";
        if(isset($_POST["PROTYPE"])){
            $var = $_POST['PROTYPE'];
        
            $proTypeFiltData = implode("','", $_POST['PROTYPE']);
            $sqlQuery .= " AND PROTYPE IN('".$proTypeFiltData."')";
        }
        $sqlQuery .= " ORDER BY PRICE";
        $result = oci_parse($this->dbConnect, $sqlQuery);
        oci_execute($result);
        oci_fetch($result);
        $totalResult = oci_num_rows($result);
        echo $totalResult;
        $searchResultHTML = '';
        if($totalResult > 0){
            echo '<div class="product-card">';
            echo '<div class="title"><h2>Our Products</h2></div>';
            while($row = oci_fetch_array($result, OCI_ASSOC)){
                $searchResultHTML .= '
                <div class="card">
                  <img src="imageuploaded/'.$row['IMAGE'].' "alt="" />
                 <div class="container-shade"></div>
                 <div class="card_btn" id="cardB">
                 <button><i class="fas fa-shopping-cart"></i></button>
                 <button><i class="far fa-heart"></i></button>
                 <button><i class="fa-solid fa-ellipsis"></i></button>
                 </div>
                 <div class="price">
                 <p class="prod">'.$row['NAME'].'</p>
                 <p class="pric">&#163; '.$row['PRICE'].'</p>
                 <div class="star-rating">
                 <div class="reviews">
                 <i class="far fa-star"></i>
                 <i class="far fa-star"></i>
                 <i class="far fa-star"></i>
                 <i class="far fa-star"></i>
                 <i class="far fa-star"></i>
                 </div>
                 <div class="num-rating"></div>
                 </div>
                 </div>
                 </div>
                ';
                echo '</div>';
            }
            
        }
        else{
            $searchResultHTML = '<h3>No results found. </h3>';
            
        }
        return $searchResultHTML;

    }
            
}
?>


